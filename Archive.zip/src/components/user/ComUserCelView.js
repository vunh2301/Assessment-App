import React from "react";
import { selectAssessments } from "../../redux/store";

function ComUserCelView(props) {
  const { userId } = props;
  return <div>Jusstin</div>;
}

export default ComUserCelView;
